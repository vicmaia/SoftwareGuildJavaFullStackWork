$(document).ready(function(){
    // hides all h1s
    $("h1").hide();
    // hides all elements with class="original"
    $(".original").hide();
    // hides all elements with id="second"
    $("#second").hide();
})
